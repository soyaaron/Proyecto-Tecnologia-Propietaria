﻿namespace Gestion_Laboratorios
{


    partial class Gestion_laboratoriosDataSet
    {
    }
}
